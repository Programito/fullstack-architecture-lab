import { provideRouter, withDisabledInitialNavigation } from '@angular/router';
import { applicationConfig, type Meta, type StoryObj } from '@storybook/angular';

import { BackLink } from './back-link';

type BackLinkStoryArgs = {
  label: string;
  routerLink: string;
};

const meta: Meta<BackLinkStoryArgs> = {
  title: 'Shared UI/BackLink',
  component: BackLink,
  tags: ['autodocs'],
  decorators: [
    applicationConfig({
      // provideRouter([]) alone lets the Router run its initial navigation against the
      // Storybook iframe URL, which never matches (there are no routes). That leaves an
      // rxjs `first()`-style navigation stream that completes without emitting, throwing
      // EmptyError and taking down the shared Storybook 