import { fireEvent, render, screen, within } from '@testing-library/angular';
import { of } from 'rxjs';
import { provideI18nTesting } from '../../../../shared/i18n/i18n-testing';
import { KEY_VALUE_STORAGE, MemoryKeyValueStorage, type KeyValueStorage } from '../../../../shared/utils/storage/key-value-storage';
import { RestaurantPosApiService } from '../../api/restaurant-pos-api.service';
import { MOCK_FLOOR_ELEMENTS, MOCK_RESTAURANT_TABLES } from '../../state/restaurant-pos.mock-data';
import { OrderWriteService } from '../../state/order-write.service';
import { RestaurantPosStore } from '../../state/restaurant-pos.store';
import { RestaurantPosServicePage } from './restaurant-pos-service-page';

describe('RestaurantPosServicePage', () => {
  const createRestaurantPosApiMock = (): Pick<
    RestaurantPosApiService,
    'listRestaurants' | 'getRestaurantMenu' | 'getRestaurantServiceFloor' | 'getRestaurantServicePoint' | 'getRestaurantServicePointOrder' | 'occupyRestaurantServicePoint' | 'sendRestaurantServicePointToKitchen' | 'markRestaurantServicePointServed' | 'chargeRestaurantServicePoint' | 'freeRestaurantServicePoint'
  > => {
    const tableStatuses = new Map<string, 'free' | 'occupied' | 'waiting_kitchen' | 'served' | 'paid'>([
      ['table-1', 'free'],
      ['table-2', 'free'],
      ['table-3', 'free'],
      ['table-4', 'free'],
      ['stool-1', 'free'],
      ['stool-2', 'free'],
      ['stool-3', 'free'],
    ]);
    const serviceOrders = new Map<
      string,
      {
        order: {
          id: string;
          tableId: string;
          status: 'open' | 'sent_to_kitchen' | 'served' | 'payment_pending' | 'paid';
          openedAt: string;
          updatedAt: string;
          subtotalCents: number;
          taxCents: number;
          totalCents: number;
          currency: string;
        };
        lines: Array<{
          id: string;
          productName: string;
          productType: 'simple' | 'combo' | 'platter';
          preparationRoute: 'direct' | 'bar' | 'kitchen' | 'cold_station' | 'dessert_station';
          quantity: number;
          unitPriceCents: number;
          subtotalCents: number;
          status: 'pending' | 'sent_to_kitchen' | 'preparing' | 'ready' | 'picked_up' | 'served' | 'cancelled';
          course: 'drinks' | 'starters' | 'mains' | 'desserts' | 'mixed' | 'none';
          kitchenNote: string | null;
          updatedAt: string;
          modifiers: Array<{ groupName: string; optionName: string; priceDeltaCents: number; quantity: number }>;
          comboSlots: Array<{ slotName: string; selectedProductName: string; supplementPriceCents: number; quantity: number }>;
        }>;
      }
    >([
      [
        'table-1',
        {
          order: {
            id: 'order:table-1',
            tableId: 'table-1',
            status: 'open',
            openedAt: '2026-06-22T10:00:00.000Z',
            updatedAt: '2026-06-22T10:00:00.000Z',
            subtotalCents: 0,
            taxCents: 0,
            totalCents: 0,
            currency: 'EUR',
          },
          lines: [],
        },
      ],
    ]);

    return ({
    listRestaurants: vi.fn(() =>
      of([
        {
          id: 'restaurant-mesaflow-centro',
          organizationId: 'org-demo',
          name: 'MesaFlow Centro',
          displayName: 'MesaFlow Centro',
          timezone: 'Europe/Madrid',
          currency: 'EUR',
          isActive: true,
        },
      ]),
    ),
    getRestaurantMenu: vi.fn(() =>
      of({
        id: 'menu-1',
        restaurantId: 'restaurant-mesaflow-centro',
        name: 'Carta',
        isActive: true,
        sections: [],
      }),
    ),
    getRestaurantServiceFloor: vi.fn(() =>
      of({
        restaurantId: 'restaurant-mesaflow-centro',
        floor: {
          id: 'floor-main',
          name: 'Sala principal',
          rows: 20,
          columns: 20,
        },
        elements: MOCK_FLOOR_ELEMENTS.map((element) => ({
          id: element.id,
          type: element.type,
          label: element.label,
          x: element.x,
          y: element.y,
          width: element.width,
          height: element.height,
          shape: element.shape ?? null,
          tableId: element.tableId ?? null,
        })),
        servicePoints: MOCK_FLOOR_ELEMENTS.filter((element) => element.tableId).map((element) => {
          const table = MOCK_RESTAURANT_TABLES.find((candidate) => candidate.id === element.tableId)!;
          return {
            table: {
              id: table.id,
              tableNumber: table.number,
              name: null,
              capacity: table.capacity,
              status: tableStatuses.get(table.id) ?? table.status,
              serviceStartedAt: tableStatuses.get(table.id) === 'free' ? null : '2026-06-22T10:15:00.000Z',
            },
            summary: {
              lineCount: serviceOrders.get(table.id)?.lines.length ?? 0,
              guestCount: table.capacity,
              totalCents: serviceOrders.get(table.id)?.order.totalCents ?? 0,
              currency: 'EUR',
              servicePhase: {
                course: (serviceOrders.get(table.id)?.lines.length ?? 0) > 0 ? ('mains' as const) : ('none' as const),
                status: (serviceOrders.get(table.id)?.lines.length ?? 0) > 0 ? ('pending' as const) : ('no_order' as const),
              },
            },
          };
        }),
        totals: {
          servicePointCount: 5,
          occupiedCount: 0,
          openOrderCount: 0,
        },
      }),
    ),
    getRestaurantServicePoint: vi.fn((_restaurantId: string, tableId: string) => {
      const table = MOCK_RESTAURANT_TABLES.find((candidate) => candidate.id === tableId)!;
      const element = MOCK_FLOOR_ELEMENTS.find((candidate) => candidate.tableId === tableId) ?? null;

      return of({
        table: {
          id: table.id,
          tableNumber: table.number,
          name: null,
          capacity: table.capacity,
          status: tableStatuses.get(table.id) ?? table.status,
          occupiedAt: tableStatuses.get(table.id) === 'free' ? null : '2026-06-22T10:15:00.000Z',
          serviceStartedAt: tableStatuses.get(table.id) === 'free' ? null : '2026-06-22T10:15:00.000Z',
        },
        floorElement: element
          ? {
              id: element.id,
              label: element.label,
              type: element.type,
              x: element.x,
              y: element.y,
              width: element.width,
              height: element.height,
              shape: element.shape ?? null,
            }
          : null,
        serviceInfo: {
          guestCount: table.capacity,
          lineCount: serviceOrders.get(tableId)?.lines.length ?? 0,
          totalCents: serviceOrders.get(tableId)?.order.totalCents ?? 0,
          currency: 'EUR',
          servicePhase: {
            course: (serviceOrders.get(tableId)?.lines.length ?? 0) > 0 ? ('mains' as const) : ('none' as const),
            status: (serviceOrders.get(tableId)?.lines.length ?? 0) > 0 ? ('pending' as const) : ('no_order' as const),
          },
          durationMinutes: 0,
        },
      });
    }),
    getRestaurantServicePointOrder: vi.fn((_: string, tableId: string) =>
      of(
        serviceOrders.get(tableId) ?? {
          order: {
            id: `order:${tableId}`,
            tableId,
            status: 'open' as const,
            openedAt: '2026-06-22T10:00:00.000Z',
            updatedAt: '2026-06-22T10:00:00.000Z',
            subtotalCents: 0,
            taxCents: 0,
            totalCents: 0,
            currency: 'EUR',
          },
          lines: [],
        },
      ),
    ),
    occupyRestaurantServicePoint: vi.fn((_restaurantId: string, tableId: string) => {
      tableStatuses.set(tableId, 'occupied');
      const table = MOCK_RESTAURANT_TABLES.find((candidate) => candidate.id === tableId)!;
      const element = MOCK_FLOOR_ELEMENTS.find((candidate) => candidate.tableId === tableId) ?? null;

      return of({
        table: {
          id: table.id,
          tableNumber: table.number,
          name: null,
          capacity: table.capacity,
          status: 'occupied' as const,
          occupiedAt: '2026-06-22T10:15:00.000Z',
          serviceStartedAt: '2026-06-22T10:15:00.000Z',
        },
        floorElement: element
          ? {
              id: element.id,
              label: element.label,
              type: element.type,
              x: element.x,
              y: element.y,
              width: element.width,
              height: element.height,
              shape: element.shape ?? null,
            }
          : null,
        serviceInfo: {
          guestCount: table.capacity,
          lineCount: 0,
          totalCents: 0,
          currency: 'EUR',
          servicePhase: {
            course: 'none' as const,
            status: 'no_order' as const,
          },
          durationMinutes: 0,
        },
      });
    }),
    sendRestaurantServicePointToKitchen: vi.fn((_restaurantId: string, tableId: string) => {
      tableStatuses.set(tableId, 'waiting_kitchen');
      serviceOrders.set(tableId, {
        order: {
          id: `order:${tableId}`,
          tableId,
          status: 'sent_to_kitchen',
          openedAt: '2026-06-22T10:00:00.000Z',
          updatedAt: '2026-06-22T10:05:00.000Z',
          subtotalCents: 1250,
          taxCents: 0,
          totalCents: 1250,
          currency: 'EUR',
        },
        lines: [
          {
            id: 'line-table-1-burger',
            productName: 'Hamburguesa craft',
            productType: 'simple' as const,
            preparationRoute: 'kitchen' as const,
            quantity: 1,
            unitPriceCents: 1250,
            subtotalCents: 1250,
            status: 'sent_to_kitchen' as const,
            course: 'mains' as const,
            kitchenNote: null,
            updatedAt: '2026-06-22T10:00:00.000Z',
            modifiers: [],
            comboSlots: [],
          },
        ],
      });
      const table = MOCK_RESTAURANT_TABLES.find((candidate) => candidate.id === tableId)!;
      const element = MOCK_FLOOR_ELEMENTS.find((candidate) => candidate.tableId === tableId) ?? null;

      return of({
        table: {
          id: table.id,
          tableNumber: table.number,
          name: null,
          capacity: table.capacity,
          status: 'waiting_kitchen' as const,
          occupiedAt: '2026-06-22T10:15:00.000Z',
          serviceStartedAt: '2026-06-22T10:15:00.000Z',
        },
        floorElement: element
          ? {
              id: element.id,
              label: element.label,
              type: element.type,
              x: element.x,
              y: element.y,
              width: element.width,
              height: element.height,
              shape: element.shape ?? null,
            }
          : null,
        serviceInfo: {
          guestCount: table.capacity,
          lineCount: serviceOrders.get(tableId)?.lines.length ?? 0,
          totalCents: serviceOrders.get(tableId)?.order.totalCents ?? 0,
          currency: 'EUR',
          servicePhase: {
            course: (serviceOrders.get(tableId)?.lines.length ?? 0) > 0 ? ('mains' as const) : ('none' as const),
            status: (serviceOrders.get(tableId)?.lines.length ?? 0) > 0 ? ('pending' as const) : ('no_order' as const),
          },
          durationMinutes: 0,
        },
      });
    }),
    markRestaurantServicePointServed: vi.fn((_restaurantId: string, tableId: string) => {
      tableStatuses.set(tableId, 'served');
      const currentOrder = serviceOrders.get(tableId);
      if (currentOrder) {
        serviceOrders.set(tableId, {
          order: {
            ...currentOrder.order,
            status: 'served',
            updatedAt: '2026-06-22T10:12:00.000Z',
          },
          lines: currentOrder.lines.map((line) => ({
            ...line,
            status: 'sent_to_kitchen',
          })),
        });
      }
      const table = MOCK_RESTAURANT_TABLES.find((candidate) => candidate.id === tableId)!;
      const element = MOCK_FLOOR_ELEMENTS.find((candidate) => candidate.tableId === tableId) ?? null;

      return of({
        table: {
          id: table.id,
          tableNumber: table.number,
          name: null,
          capacity: table.capacity,
          status: 'served' as const,
          occupiedAt: '2026-06-22T10:15:00.000Z',
          serviceStartedAt: '2026-06-22T10:15:00.000Z',
        },
        floorElement: element
          ? {
              id: element.id,
              label: element.label,
              type: element.type,
              x: element.x,
              y: element.y,
              width: element.width,
              height: element.height,
              shape: element.shape ?? null,
            }
          : null,
        serviceInfo: {
          guestCount: table.capacity,
          lineCount: currentOrder?.lines.length ?? 0,
          totalCents: currentOrder?.order.totalCents ?? 0,
          currency: 'EUR',
          servicePhase: {
            course: 'none' as const,
            status: 'served' as const,
          },
          durationMinutes: 0,
        },
      });
    }),
    chargeRestaurantServicePoint: vi.fn((_restaurantId: string, tableId: string) => {
      tableStatuses.set(tableId, 'paid');
      const table = MOCK_RESTAURANT_TABLES.find((candidate) => candidate.id === tableId)!;
      const element = MOCK_FLOOR_ELEMENTS.find((candidate) => candidate.tableId === tableId) ?? null;

      return of({
        table: {
          id: table.id,
          tableNumber: table.number,
          name: null,
          capacity: table.capacity,
          status: 'paid' as const,
          occupiedAt: '2026-06-22T10:15:00.000Z',
          serviceStartedAt: '2026-06-22T10:15:00.000Z',
        },
        floorElement: element
          ? {
              id: element.id,
              label: element.label,
              type: element.type,
              x: element.x,
              y: element.y,
              width: element.width,
              height: element.height,
              shape: element.shape ?? null,
            }
          : null,
        serviceInfo: {
          guestCount: table.capacity,
          lineCount: 0,
          totalCents: 0,
          currency: 'EUR',
          servicePhase: {
            course: 'none' as const,
            status: 'no_order' as const,
          },
          durationMinutes: 0,
        },
      });
    }),
    freeRestaurantServicePoint: vi.fn((_restaurantId: string, tableId: string) => {
      tableStatuses.set(tableId, 'free');
      const table = MOCK_RESTAURANT_TABLES.find((candidate) => candidate.id === tableId)!;
      const element = MOCK_FLOOR_ELEMENTS.find((candidate) => candidate.tableId === tableId) ?? null;

      return of({
        table: {
          id: table.id,
          tableNumber: table.number,
          name: null,
          capacity: table.capacity,
          status: 'free' as const,
          occupiedAt: null,
          serviceStartedAt: null,
        },
        floorElement: element
          ? {
              id: element.id,
              label: element.label,
              type: element.type,
              x: element.x,
              y: element.y,
              width: element.width,
              height: element.height,
              shape: element.shape ?? null,
            }
          : null,
        serviceInfo: {
          guestCount: table.capacity,
          lineCount: 0,
          totalCents: 0,
          currency: 'EUR',
          servicePhase: {
            course: 'none' as const,
            status: 'no_order' as const,
          },
          durationMinutes: 0,
        },
      });
    }),
  });
  };

  const renderServicePage = async (storage?: KeyValueStorage, apiMock = createRestaurantPosApiMock()) => {
    const i18n = provideI18nTesting();
    const result = await render(RestaurantPosServicePage, {
      imports: [...i18n.imports],
      providers: [
        ...(storage ? [...i18n.providers, { provide: KEY_VALUE_STORAGE, useValue: storage }] : [...i18n.providers]),
        { provide: RestaurantPosApiService, useValue: apiMock },
        OrderWriteService,
      ],
    });

    result.fixture.detectChanges();
    return result;
  };

  const getProductDialog = () => screen.getByRole('dialog', { name: /Añadir productos/i });
  const queryProductDialog = () => screen.queryByRole('dialog', { name: /Añadir productos/i });

  const addProductFromSearch = (fixture: { detectChanges: () => void }, productName: RegExp) => {
    fireEvent.click(screen.getByRole('button', { name: /Buscar producto/i }));
    fixture.detectChanges();
    const dialog = getProductDialog();
    const product = within(dialog).getByText(productName).textContent ?? '';
    const action =
      within(dialog).queryByRole('button', { name: new RegExp(`Añadir una unidad de ${product}`) }) ??
      within(dialog).getByRole('button', { name: new RegExp(`Configurar ${product}`) });
    fireEvent.click(action);
    fixture.detectChanges();
    const customizer = screen.queryByRole('dialog', { name: new RegExp(product) });
    if (customizer) {
      fireEvent.click(within(customizer).getByRole('button', { name: /Añadir por/i }));
      fixture.detectChanges();
    }
    fireEvent.click(within(dialog).getByRole('button', { name: 'Cerrar' }));
    fixture.detectChanges();
  };

  it('renders a compact service floor and empty selected-table panel without the preparation board', async () => {
    const { container } = await renderServicePage();

    expect(screen.getByRole('heading', { name: 'Servicio de sala' })).toBeTruthy();
    expect(screen.getByRole('heading', { name: 'Plano de servicio' })).toBeTruthy();
    expect(screen.getByRole('heading', { name: 'Selecciona una mesa' })).toBeTruthy();
    expect(screen.getByText('Selecciona una mesa para empezar.')).toBeTruthy();
    expect(screen.getByLabelText('Panel de mesa seleccionada')).toBeTruthy();
    expect(screen.getByText('0/5')).toBeTruthy();
    expect(screen.getByText('Pagada')).toBeTruthy();
    expect(screen.queryByText('Añadir rápido')).toBeNull();
    expect(screen.queryByRole('region', { name: 'Preparación' })).toBeNull();
    expect(screen.getByRole('button', { name: /Buscar mesa\/taburete/i })).toBeTruthy();
    expect(screen.getByRole('link', { name: /Cocina/i }).getAttribute('href')).toBe('/restaurant-pos/kitchen');
    expect(screen.getByLabelText('M1 mesa, Libre')).toBeTruthy();
    expect(screen.queryByRole('toolbar', { name: 'Acciones del elemento del plano' })).toBeNull();

    const tablePanelHost = container.querySelector('app-service-table-panel');
    expect(tablePanelHost?.className).toContain('w-full');
    expect(tablePanelHost?.className).toContain('self-start');
    expect(tablePanelHost?.className).toContain('xl:w-[22rem]');
    expect(tablePanelHost?.className).not.toMatch(/\babsolute\b|\bfixed\b/);
  });

  it('opens the selected table panel from the floor plan', async () => {
    await renderServicePage();

    fireEvent.click(screen.getByLabelText('M1 mesa, Libre'));

    expect(screen.getByRole('heading', { name: 'Mesa 1' })).toBeTruthy();
    expect(screen.getByText('Sin iniciar')).toBeTruthy();
    expect(screen.getByText('Todavía no hay productos añadidos.')).toBeTruthy();
  });

  it('loads the service floor on init and fetches the selected service point from the backend', async () => {
    const apiMock = createRestaurantPosApiMock();

    await renderServicePage(undefined, apiMock);
    fireEvent.click(screen.getByLabelText('M1 mesa, Libre'));

    expect(apiMock.listRestaurants).toHaveBeenCalledTimes(1);
    expect(apiMock.getRestaurantServiceFloor).toHaveBeenCalledWith('restaurant-mesaflow-centro');
    expect(apiMock.getRestaurantServicePoint).toHaveBeenCalledWith('restaurant-mesaflow-centro', 'table-1');
    expect(apiMock.getRestaurantServicePointOrder).toHaveBeenCalledWith('restaurant-mesaflow-centro', 'table-1');
  });

  it('occupies the selected table through the backend endpoint', async () => {
    const apiMock = createRestaurantPosApiMock();
    const { fixture } = await renderServicePage(undefined, apiMock);
    const store = fixture.debugElement.injector.get(RestaurantPosStore);

    fireEvent.click(screen.getByLabelText('M1 mesa, Libre'));
    fireEvent.click(screen.getByRole('button', { name: /Iniciar servicio/i }));
    fixture.detectChanges();

    expect(apiMock.occupyRestaurantServicePoint).toHaveBeenCalledWith('restaurant-mesaflow-centro', 'table-1');
    expect(store.selectedTable()).toEqual(expect.objectContaining({ id: 'table-1', status: 'occupied' }));
  });

  it('sends the selected table order to kitchen through the backend endpoint', async () => {
    const apiMock = createRestaurantPosApiMock();
    const { fixture } = await renderServicePage(undefined, apiMock);
    const store = fixture.debugElement.injector.get(RestaurantPosStore);

    fireEvent.click(screen.getByLabelText('M1 mesa, Libre'));
    addProductFromSearch(fixture, /^Hamburguesa craft/);
    fireEvent.click(screen.getByRole('button', { name: /Cocina/i }));
    fixture.detectChanges();

    expect(apiMock.sendRestaurantServicePointToKitchen).toHaveBeenCalledWith('restaurant-mesaflow-centro', 'table-1');
    expect(store.selectedTable()).toEqual(expect.objectContaining({ id: 'table-1', status: 'waiting_kitchen' }));
  });

  it('marks the selected table as served through the backend endpoint', async () => {
    const apiMock = createRestaurantPosApiMock();
    const { fixture } = await renderServicePage(undefined, apiMock);
    const store = fixture.debugElement.injector.get(RestaurantPosStore);

    fireEvent.click(screen.getByLabelText('M1 mesa, Libre'));
    addProductFromSearch(fixture, /^Hamburguesa craft/);
    fireEvent.click(screen.getByRole('button', { name: /Cocina/i }));
    fixture.detectChanges();
    fireEvent.click(screen.getByRole('button', { name: /Marcar el pedido de la mesa seleccionada como servido/i }));
    fixture.detectChanges();

    expect(apiMock.markRestaurantServicePointServed).toHaveBeenCalledWith('restaurant-mesaflow-centro', 'table-1');
    expect(store.selectedTable()).toEqual(expect.objectContaining({ id: 'table-1', status: 'served' }));
  });

  it('charges the selected table through the backend endpoint', async () => {
    const apiMock = createRestaurantPosApiMock();
    const { fixture } = await renderServicePage(undefined, apiMock);
    const store = fixture.debugElement.injector.get(RestaurantPosStore);

    fireEvent.click(screen.getByLabelText('M1 mesa, Libre'));
    addProductFromSearch(fixture, /^Hamburguesa craft/);
    fireEvent.click(screen.getByRole('button', { name: /Cocina/i }));
    fixture.detectChanges();
    fireEvent.click(screen.getByRole('button', { name: /Marcar el pedido de la mesa seleccionada como servido/i }));
    fixture.detectChanges();
    fireEvent.click(screen.getByRole('button', { name: /Efectivo/i }));
    fireEvent.click(screen.getByRole('button', { name: /Cobrar/i }));
    fixture.detectChanges();

    expect(apiMock.chargeRestaurantServicePoint).toHaveBeenCalledWith('restaurant-mesaflow-centro', 'table-1');
    expect(store.selectedOrder()).toEqual(expect.objectContaining({ paymentMethod: 'cash', status: 'paid' }));
    expect(store.selectedTable()).toEqual(expect.objectContaining({ id: 'table-1', status: 'paid' }));
  });

  it('opens a selected stool as a one-person service panel', async () => {
    const { fixture } = await renderServicePage();
    const store = fixture.debugElement.injector.get(RestaurantPosStore);

    fireEvent.click(screen.getByLabelText('Stool 1 mesa, Libre'));

    expect(store.selectedTableId()).toBe('stool-1');
    expect(screen.getByRole('heading', { name: 'T1' })).toBeTruthy();
    expect(screen.getByText('1 pax')).toBeTruthy();
  });

  it('filters products in a modal and adds the selected result to the current order', async () => {
    const { fixture } = await renderServicePage();
    const store = fixture.debugElement.injector.get(RestaurantPosStore);

    fireEvent.click(screen.getByLabelText('M1 mesa, Libre'));
    fireEvent.click(within(screen.getByLabelText('Panel de mesa seleccionada')).getByRole('button', { name: /Buscar producto/i }));
    fireEvent.input(within(getProductDialog()).getByRole('searchbox', { name: /Buscar producto/i }), {
      target: { value: 'limonada' },
    });
    fixture.detectChanges();
    fireEvent.click(within(getProductDialog()).getByRole('button', { name: 'Añadir una unidad de Limonada con gas' }));
    fixture.detectChanges();

    expect(store.selectedOrder()?.lines[0]).toEqual(expect.objectContaining({ productName: 'Limonada con gas' }));
    expect(screen.getByText('1 x Limonada con gas')).toBeTruthy();
    expect(getProductDialog()).toBeTruthy();
    expect(within(getProductDialog()).getByText('Añadido')).toBeTruthy();
    expect(within(getProductDialog()).getByLabelText('Cantidad de Limonada con gas: 1')).toBeTruthy();
  });

  it('updates product quantities live from the search modal and closes it with finish', async () => {
    const { fixture } = await renderServicePage();
    const store = fixture.debugElement.injector.get(RestaurantPosStore);

    fireEvent.click(screen.getByLabelText('M1 mesa, Libre'));
    fireEvent.click(within(screen.getByLabelText('Panel de mesa seleccionada')).getByRole('button', { name: /Buscar producto/i }));
    fixture.detectChanges();

    const dialog = getProductDialog();
    fireEvent.click(within(dialog).getByRole('button', { name: 'Añadir una unidad de Limonada con gas' }));
    fixture.detectChanges();
    fireEvent.click(within(dialog).getByRole('button', { name: 'Añadir una unidad de Limonada con gas' }));
    fixture.detectChanges();

    expect(store.selectedOrder()?.lines.find((line) => line.productName === 'Limonada con gas')).toEqual(expect.objectContaining({ quantity: 2 }));
    expect(screen.getByText('2 x Limonada con gas')).toBeTruthy();
    expect(within(dialog).getByLabelText('Cantidad de Limonada con gas: 2')).toBeTruthy();

    fireEvent.click(within(dialog).getByRole('button', { name: 'Quitar una unidad de Limonada con gas' }));
    fixture.detectChanges();
    expect(store.selectedOrder()?.lines.find((line) => line.productName === 'Limonada con gas')).toEqual(expect.objectContaining({ quantity: 1 }));

    fireEvent.click(within(dialog).getByRole('button', { name: 'Quitar una unidad de Limonada con gas' }));
    fixture.detectChanges();
    expect(store.selectedOrder()?.lines.find((line) => line.productName === 'Limonada con gas')).toBeUndefined();
    expect(within(dialog).queryByRole('button', { name: 'Quitar una unidad de Limonada con gas' })).toBeNull();
    expect(within(dialog).getByRole('button', { name: 'Añadir una unidad de Limonada con gas' })).toBeTruthy();

    fireEvent.click(within(dialog).getByRole('button', { name: 'Cerrar' }));
    fixture.detectChanges();

    expect(queryProductDialog()).toBeNull();
  });

  it('opens the customizer for configurable products and adds the selected snapshot', async () => {
    const { fixture } = await renderServicePage();
    const store = fixture.debugElement.injector.get(RestaurantPosStore);

    fireEvent.click(screen.getByLabelText('M1 mesa, Libre'));
    fireEvent.click(within(screen.getByLabelText('Panel de mesa seleccionada')).getByRole('button', { name: /Buscar producto/i }));
    fixture.detectChanges();

    const searchDialog = getProductDialog();
    fireEvent.click(within(searchDialog).getByRole('button', { name: 'Configurar Hamburguesa craft' }));
    fixture.detectChanges();

    const customizer = screen.getByRole('dialog', { name: /Hamburguesa craft/i });
    fireEvent.click(within(customizer).getByLabelText(/Bacon/i));
    fireEvent.input(within(customizer).getByRole('textbox'), { target: { value: 'Sin prisa' } });
    fireEvent.click(within(customizer).getByRole('button', { name: /Añadir por/i }));
    fixture.detectChanges();

    const line = store.selectedOrder()?.lines.find((currentLine) => currentLine.productName === 'Hamburguesa craft');
    expect(line).toEqual(
      expect.objectContaining({
        productId: 'product-1',
        quantity: 1,
        kitchenNote: 'Sin prisa',
        unitPrice: 14,
      }),
    );
    expect(line?.selectedModifiers.map((modifier) => modifier.optionId)).toContain('extra-bacon');
    const tablePanel = screen.getByLabelText('Panel de mesa seleccionada');
    expect(within(tablePanel).getByText(/Bacon/)).toBeTruthy();
    expect(within(tablePanel).getByText(/Nota: Sin prisa/)).toBeTruthy();
  });

  it('opens the product customizer for platter products with modifiers', async () => {
    const { fixture } = await renderServicePage();
    const store = fixture.debugElement.injector.get(RestaurantPosStore);

    fireEvent.click(screen.getByLabelText('M1 mesa, Libre'));
    fireEvent.click(within(screen.getByLabelText('Panel de mesa seleccionada')).getByRole('button', { name: /Buscar producto/i }));
    fixture.detectChanges();

    const searchDialog = getProductDialog();
    fireEvent.input(within(searchDialog).getByRole('searchbox', { name: /Buscar producto/i }), {
      target: { value: 'lomo' },
    });
    fixture.detectChanges();

    expect(within(searchDialog).getByText('Plato combinado')).toBeTruthy();
    fireEvent.click(within(searchDialog).getByRole('button', { name: 'Configurar plato Plato combinado de lomo' }));
    fixture.detectChanges();

    const customizer = screen.getByRole('dialog', { name: /Plato combinado de lomo/i });
    fireEvent.click(within(customizer).getByLabelText(/Huevo extra/i));
    fireEvent.click(within(customizer).getByRole('button', { name: /A.adir por/i }));
    fixture.detectChanges();

    const line = store.selectedOrder()?.lines.find((currentLine) => currentLine.productName === 'Plato combinado de lomo');
    expect(line).toEqual(
      expect.objectContaining({
        productId: 'product-17',
        unitPrice: 14.1,
        platterComponents: [
          expect.objectContaining({ name: 'Lomo' }),
          expect.objectContaining({ name: 'Huevo' }),
          expect.objectContaining({ name: 'Patatas fritas' }),
          expect.objectContaining({ name: 'Ensalada' }),
        ],
      }),
    );
    expect(line?.selectedModifiers.map((modifier) => modifier.optionId)).toContain('platter-extra-egg');
    const tablePanel = screen.getByLabelText('Panel de mesa seleccionada');
    expect(within(tablePanel).getByText(/Incluye:/)).toBeTruthy();
    expect(within(tablePanel).getByText(/lomo, huevo, patatas fritas, ensalada/)).toBeTruthy();

    fireEvent.click(within(searchDialog).getByRole('button', { name: /Añadir una unidad de Plato combinado de lomo con Huevo extra/ }));
    fixture.detectChanges();

    expect(screen.queryByRole('dialog', { name: /Plato combinado de lomo/i })).toBeNull();
    expect(store.selectedOrder()?.lines.find((currentLine) => currentLine.productName === 'Plato combinado de lomo')).toEqual(
      expect.objectContaining({ quantity: 2 }),
    );
    expect(within(searchDialog).getByLabelText(/Cantidad de Plato combinado de lomo .*: 2/)).toBeTruthy();
  });

  it('adds platter products without modifiers directly from product search', async () => {
    const { fixture } = await renderServicePage();
    const store = fixture.debugElement.injector.get(RestaurantPosStore);

    fireEvent.click(screen.getByLabelText('M1 mesa, Libre'));
    fireEvent.click(within(screen.getByLabelText('Panel de mesa seleccionada')).getByRole('button', { name: /Buscar producto/i }));
    fixture.detectChanges();

    const searchDialog = getProductDialog();
    fireEvent.input(within(searchDialog).getByRole('searchbox', { name: /Buscar producto/i }), {
      target: { value: 'vegetal' },
    });
    fixture.detectChanges();

    const addButton = within(searchDialog).getByRole('button', { name: /A.adir una unidad de Plato combinado vegetal/ });
    expect(addButton.textContent?.trim()).toMatch(/A.adir/);
    fireEvent.click(addButton);
    fixture.detectChanges();

    expect(screen.queryByRole('dialog', { name: /Plato combinado vegetal/i })).toBeNull();
    expect(store.selectedOrder()?.lines.find((currentLine) => currentLine.productId === 'product-19')).toEqual(
      expect.objectContaining({
        productName: 'Plato combinado vegetal',
        platterComponents: expect.arrayContaining([expect.objectContaining({ name: 'Ensalada' })]),
      }),
    );
    expect(screen.getByText('1 x Plato combinado vegetal')).toBeTruthy();
  });

  it('opens combo customizer from product search and adds the configured menu', async () => {
    const { fixture } = await renderServicePage();
    const store = fixture.debugElement.injector.get(RestaurantPosStore);

    fireEvent.click(screen.getByLabelText('M1 mesa, Libre'));
    fireEvent.click(within(screen.getByLabelText('Panel de mesa seleccionada')).getByRole('button', { name: /Buscar producto/i }));
    fixture.detectChanges();

    const dialog = getProductDialog();
    const comboAdd = within(dialog).getByRole('button', { name: 'Configurar menú Menu Classic Burger' });

    expect(within(dialog).getByText('Menu Classic Burger')).toBeTruthy();
    expect(within(dialog).getByText('Menú')).toBeTruthy();
    expect(comboAdd.hasAttribute('disabled')).toBe(false);

    fireEvent.click(comboAdd);
    fixture.detectChanges();

    const comboDialog = screen.getByRole('dialog', { name: 'Menu Classic Burger' });
    expect((within(comboDialog).getByRole('radio', { name: /Hamburguesa clásica/i }) as HTMLInputElement).checked).toBe(true);
    fireEvent.click(within(comboDialog).getByRole('button', { name: 'Añadir menú' }));
    fixture.detectChanges();

    const line = store.selectedOrder()?.lines.find((currentLine) => currentLine.productId === 'product-16');
    expect(line).toEqual(
      expect.objectContaining({
        productName: 'Menu Classic Burger',
        unitPrice: 13.5,
        selectedComboSlots: expect.arrayContaining([
          expect.objectContaining({ slotName: 'Hamburguesa' }),
          expect.objectContaining({ slotName: 'Acompanamiento' }),
          expect.objectContaining({ slotName: 'Bebida' }),
        ]),
      }),
    );
    const tablePanel = screen.getByLabelText('Panel de mesa seleccionada');
    expect(within(tablePanel).getByText('1 x Menu Classic Burger')).toBeTruthy();
    expect(within(tablePanel).getByText(/Hamburguesa clásica/)).toBeTruthy();

    fireEvent.click(within(dialog).getByRole('button', { name: /Añadir una unidad de Menu Classic Burger con/i }));
    fixture.detectChanges();

    expect(screen.queryByRole('dialog', { name: 'Menu Classic Burger' })).toBeNull();
    expect(store.selectedOrder()?.lines.find((currentLine) => currentLine.productId === 'product-16')).toEqual(expect.objectContaining({ quantity: 2 }));
    expect(within(dialog).getByLabelText(/Cantidad de Menu Classic Burger .*: 2/i)).toBeTruthy();

    fireEvent.click(within(dialog).getByRole('button', { name: 'Crear otra opción de Menu Classic Burger' }));
    fixture.detectChanges();

    const secondComboDialog = screen.getByRole('dialog', { name: 'Menu Classic Burger' });
    fireEvent.click(within(secondComboDialog).getByRole('radio', { name: /Agua/i }));
    fireEvent.click(within(secondComboDialog).getByRole('button', { name: 'Añadir menú' }));
    fixture.detectChanges();

    expect(store.selectedOrder()?.lines.filter((currentLine) => currentLine.productId === 'product-16')).toHaveLength(2);
    expect(within(dialog).getByText('3 en pedido · 2 opciones')).toBeTruthy();
    fireEvent.click(within(dialog).getByRole('button', { name: 'Ver opciones' }));
    fixture.detectChanges();
    expect(within(dialog).getByText(/2 x .*Coca-Cola/)).toBeTruthy();
    expect(within(dialog).getByText(/1 x .*Agua/)).toBeTruthy();
  });

  it('filters the product search by favorites and lets favorites be updated from the dialog', async () => {
    const { fixture } = await renderServicePage();

    fireEvent.click(screen.getByLabelText('M1 mesa, Libre'));
    fireEvent.click(within(screen.getByLabelText('Panel de mesa seleccionada')).getByRole('button', { name: /Buscar producto/i }));
    fixture.detectChanges();

    const dialog = getProductDialog();
    fireEvent.click(within(dialog).getByRole('button', { name: 'Favoritos' }));
    fixture.detectChanges();

    expect(within(dialog).getByText('Hamburguesa craft')).toBeTruthy();
    expect(within(dialog).getByText('Limonada con gas')).toBeTruthy();
    expect(within(dialog).queryByText('Croquetas de jamón ibérico')).toBeNull();

    fireEvent.click(within(dialog).getByRole('button', { name: 'Quitar Hamburguesa craft de favoritos' }));
    fixture.detectChanges();

    expect(within(dialog).queryByText('Hamburguesa craft')).toBeNull();

    fireEvent.click(within(dialog).getByRole('button', { name: 'Todos' }));
    fixture.detectChanges();
    fireEvent.click(within(dialog).getByRole('button', { name: 'Añadir Croquetas de jamón ibérico a favoritos' }));
    fixture.detectChanges();
    fireEvent.click(within(dialog).getByRole('button', { name: 'Favoritos' }));
    fixture.detectChanges();

    expect(within(dialog).getByText('Croquetas de jamón ibérico')).toBeTruthy();
  });

  it('loads and persists favorite products in local storage', async () => {
    const storage = new MemoryKeyValueStorage();
    storage.setItem('locale', 'es');
    storage.setItem('restaurant-pos.favorite-products', JSON.stringify(['product-2']));
    const { fixture } = await renderServicePage(storage);

    fireEvent.click(screen.getByLabelText('M1 mesa, Libre'));
    fireEvent.click(within(screen.getByLabelText('Panel de mesa seleccionada')).getByRole('button', { name: /Buscar producto/i }));
    fixture.detectChanges();

    const dialog = getProductDialog();
    fireEvent.click(within(dialog).getByRole('button', { name: 'Favoritos' }));
    fixture.detectChanges();

    expect(within(dialog).getByText('Croquetas de jamón ibérico')).toBeTruthy();
    expect(within(dialog).queryByText('Hamburguesa craft')).toBeNull();

    fireEvent.click(within(dialog).getByRole('button', { name: 'Todos' }));
    fixture.detectChanges();
    fireEvent.click(within(dialog).getByRole('button', { name: 'Añadir Hamburguesa craft a favoritos' }));
    fixture.detectChanges();

    expect(storage.getItem('restaurant-pos.favorite-products')).toBe(JSON.stringify(['product-2', 'product-1']));
  });

  it('filters the product search by service section chip', async () => {
    const { fixture } = await renderServicePage();
    const store = fixture.debugElement.injector.get(RestaurantPosStore);

    fireEvent.click(screen.getByLabelText('M1 mesa, Libre'));
    fireEvent.click(within(screen.getByLabelText('Panel de mesa seleccionada')).getByRole('button', { name: /Buscar producto/i }));
    fixture.detectChanges();

    const dialog = getProductDialog();
    fireEvent.click(within(dialog).getByRole('button', { name: 'Bebidas' }));
    fixture.detectChanges();

    expect(within(dialog).getByRole('button', { name: 'Todos' }).textContent).toContain(String(store.products().filter((product) => product.available).length));
    expect(within(dialog).getByText('Limonada con gas')).toBeTruthy();
    expect(within(dialog).getByText('Café solo')).toBeTruthy();
    expect(within(dialog).queryByText('Hamburguesa craft')).toBeNull();
    expect(within(dialog).queryByText('Ensalada César')).toBeNull();
  });

  it('adds products and advances the selected table through kitchen, served, and payment states', async () => {
    const { fixture } = await renderServicePage();
    const store = fixture.debugElement.injector.get(RestaurantPosStore);

    fireEvent.click(screen.getByLabelText('M1 mesa, Libre'));
    addProductFromSearch(fixture, /^Hamburguesa craft/);

    expect(screen.getByText('1 x Hamburguesa craft')).toBeTruthy();
    fireEvent.click(screen.getByRole('button', { name: 'Añadir una unidad de Hamburguesa craft' }));
    fixture.detectChanges();
    expect(screen.getByText('2 x Hamburguesa craft')).toBeTruthy();
    fireEvent.click(screen.getByRole('button', { name: 'Quitar una unidad de Hamburguesa craft' }));
    fixture.detectChanges();
    expect(screen.getByText('1 x Hamburguesa craft')).toBeTruthy();
    expect(screen.getByRole('heading', { name: 'Principal' })).toBeTruthy();
    expect(screen.getAllByText('Pendiente').length).toBeGreaterThan(0);
    expect(store.selectedTable()?.status).toBe('occupied');

    fireEvent.click(screen.getByRole('button', { name: /Cocina/i }));
    fixture.detectChanges();

    expect(store.selectedTable()?.status).toBe('waiting_kitchen');
    expect(screen.getAllByText('En cocina').length).toBeGreaterThan(0);

    expect(screen.queryByRole('region', { name: 'Preparación' })).toBeNull();
    fireEvent.input(screen.getByRole('textbox', { name: 'Nota para Hamburguesa craft' }), { target: { value: 'Sin cebolla' } });
    fireEvent.click(screen.getByRole('button', { name: /Marcar el pedido de la mesa seleccionada como servido/i }));
    fixture.detectChanges();

    expect(store.selectedOrder()?.lines[0]).toEqual(expect.objectContaining({ note: 'Sin cebolla', status: 'served' }));
    expect(store.selectedTable()?.status).toBe('served');
    expect(screen.getAllByText('Servido').length).toBeGreaterThan(0);

    fireEvent.click(screen.getByRole('button', { name: /Efectivo/i }));
    fireEvent.click(screen.getByRole('button', { name: /Cobrar/i }));
    fixture.detectChanges();

    expect(store.selectedOrder()?.paymentMethod).toBe('cash');
    expect(store.selectedOrder()?.status).toBe('paid');
    expect(store.selectedTable()?.status).toBe('paid');
  });

  it('removes a product line from the selected order', async () => {
    const { fixture } = await renderServicePage();
    const store = fixture.debugElement.injector.get(RestaurantPosStore);

    fireEvent.click(screen.getByLabelText('M1 mesa, Libre'));
    addProductFromSearch(fixture, /^Hamburguesa craft/);
    addProductFromSearch(fixture, /^Limonada con gas/);

    fireEvent.click(screen.getByRole('button', { name: 'Eliminar Hamburguesa craft del pedido' }));
    fixture.detectChanges();

    expect(store.selectedOrder()?.lines.map((line) => line.productName)).toEqual(['Limonada con gas']);
    expect(screen.queryByText('1 x Hamburguesa craft')).toBeNull();
    expect(screen.getByText('1 x Limonada con gas')).toBeTruthy();
  });

  it('opens a simulated card gateway and accepts or rejects payment without losing the order', async () => {
    const { fixture } = await renderServicePage();
    const store = fixture.debugElement.injector.get(RestaurantPosStore);

    fireEvent.click(screen.getByLabelText('M1 mesa, Libre'));
    addProductFromSearch(fixture, /^Hamburguesa craft/);
    fireEvent.click(screen.getByRole('button', { name: /Tarjeta/i }));
    fireEvent.click(screen.getByRole('button', { name: /Cobrar/i }));
    fixture.detectChanges();

    expect(screen.getByRole('dialog', { name: /Pasarela bancaria/i })).toBeTruthy();
    expect(screen.getByText(/Conectando con terminal/i)).toBeTruthy();

    fireEvent.click(screen.getByRole('button', { name: /Error/i }));
    fixture.detectChanges();

    expect(screen.getByText(/Pago rechazado/i)).toBeTruthy();
    expect(store.selectedTable()?.status).toBe('occupied');
    expect(store.selectedOrder()?.status).toBe('open');
    expect(store.selectedOrder()?.lines.length).toBe(1);

    fireEvent.click(screen.getByRole('button', { name: /Aceptar pago/i }));
    fixture.detectChanges();

    expect(store.selectedOrder()?.paymentMethod).toBe('card');
    expect(store.selectedOrder()?.status).toBe('paid');
    expect(store.selectedTable()?.status).toBe('paid');
    expect(screen.queryByRole('dialog', { name: /Pasarela bancaria/i })).toBeNull();
  });

  it('searches a table or stool, selects it, and focuses it in the floor plan', async () => {
    vi.useFakeTimers();
    const scrollIntoView = vi.fn();
    const focus = vi.fn();
    const originalScrollIntoView = HTMLElement.prototype.scrollIntoView;
    const originalFocus = HTMLElement.prototype.focus;
    HTMLElement.prototype.scrollIntoView = scrollIntoView;
    HTMLElement.prototype.focus = focus;
    const { fixture } = await renderServicePage();
    const store = fixture.debugElement.injector.get(RestaurantPosStore);

    fireEvent.click(screen.getByRole('button', { name: /Buscar mesa\/taburete/i }));
    fireEvent.input(screen.getByRole('searchbox', { name: /Buscar mesa\/taburete/i }), { target: { value: 'Stool 2' } });
    fixture.detectChanges();
    fireEvent.click(within(screen.getByRole('dialog', { name: /Buscar mesa\/taburete/i })).getByRole('button', { name: /Stool 2/i }));
    fixture.detectChanges();
    vi.runOnlyPendingTimers();

    expect(store.selectedTableId()).toBe('stool-2');
    expect(screen.queryByRole('dialog', { name: /Buscar mesa\/taburete/i })).toBeNull();
    expect(scrollIntoView).toHaveBeenCalledWith({ block: 'center', inline: 'center', behavior: 'smooth' });
    expect(focus).toHaveBeenCalledWith({ preventScroll: true });

    HTMLElement.prototype.scrollIntoView = originalScrollIntoView;
    HTMLElement.prototype.focus = originalFocus;
    vi.useRealTimers();
  });

  it('filters service point search by table status', async () => {
    const { fixture } = await renderServicePage();

    fireEvent.click(screen.getByLabelText('M1 mesa, Libre'));
    addProductFromSearch(fixture, /^Hamburguesa craft/);
    fireEvent.click(screen.getByRole('button', { name: /Buscar mesa\/taburete/i }));
    fireEvent.change(screen.getByRole('combobox', { name: 'Estado' }), { target: { value: 'occupied' } });
    fixture.detectChanges();

    const dialog = screen.getByRole('dialog', { name: /Buscar mesa\/taburete/i });
    expect(within(dialog).getByRole('button', { name: /M1/ })).toBeTruthy();
    expect(within(dialog).queryByRole('button', { name: /M2/ })).toBeNull();
  });

  it('returns to the previous selected service point', async () => {
    const { fixture } = await renderServicePage();
    const store = fixture.debugElement.injector.get(RestaurantPosStore);

    fireEvent.click(screen.getByLabelText('M1 mesa, Libre'));
    fireEvent.click(screen.getByLabelText('M2 mesa, Libre'));
    fixture.detectChanges();

    fireEvent.click(screen.getByRole('button', { name: 'Volver a M1' }));
    fixture.detectChanges();

    expect(store.selectedTableId()).toBe('table-1');
    expect(screen.getByRole('button', { name: 'Volver a M2' })).toBeTruthy();
  });

  it('marks cleaning and frees the selected table from the service panel', async () => {
    const { fixture } = await renderServicePage();
    const store = fixture.debugElement.injector.get(RestaurantPosStore);

    fireEvent.click(screen.getByLabelText('M1 mesa, Libre'));
    addProductFromSearch(fixture, /^Hamburguesa craft/);
    fireEvent.click(screen.getByRole('button', { name: /Limpieza/i }));
    fixture.detectChanges();

    expect(store.selectedTable()?.status).toBe('cleaning');
    expect(within(screen.getByLabelText('Panel de mesa seleccionada')).getAllByText('Limpieza').length).toBeGreaterThan(0);

    fireEvent.click(screen.getByRole('button', { name: /Liberar la mesa seleccionada/i }));
    fixture.detectChanges();

    expect(screen.getByRole('dialog', { name: 'Liberar mesa' })).toBeTruthy();
    fireEvent.click(within(screen.getByRole('dialog', { name: 'Liberar mesa' })).getByRole('button', { name: 'Liberar mesa' }));
    fixture.detectChanges();

    expect(store.selectedTable()?.status).toBe('free');
    expect(store.selectedOrder()?.lines).toEqual([]);
  });
});
