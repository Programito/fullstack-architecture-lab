import { fireEvent, render, screen, within } from '@testing-library/angular';
import { provideI18nTesting } from '../../../../shared/i18n/i18n-testing';
import type { OrderCourse, OrderCourseGroup, OrderLineProductSnapshot, RestaurantTable, ServiceTableInfo, TableOrder } from '../../models/restaurant-pos.models';
import { ServiceTablePanel } from './service-table-panel';

describe('ServiceTablePanel', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date('2026-06-10T12:30:00.000Z'));
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  const table: RestaurantTable = {
    id: 'table-1',
    number: 1,
    capacity: 4,
    status: 'occupied',
    total: 12.5,
    openDuration: '10m',
    occupiedAt: '2026-06-10T12:05:00.000Z',
    serviceStartedAt: '2026-06-10T12:05:00.000Z',
  };

  const productSnapshot = (
    productId: string,
    productName: string,
    basePrice: number,
    course: OrderCourse,
    requiresReadyBeforeServe = true,
  ): OrderLineProductSnapshot => ({
    productId,
    productName,
    productType: 'simple',
    basePrice,
    course,
    preparationPolicy: {
      route: requiresReadyBeforeServe ? 'kitchen' : 'bar',
      requiresReadyBeforeServe,
    },
  });

  const order: TableOrder = {
    tableId: 'table-1',
    status: 'open',
    paymentMethod: 'cash',
    total: 12.5,
    lines: [
      {
        id: 'line-burger',
        productSnapshot: productSnapshot('burger', 'Craft Burger', 12.5, 'main'),
        productId: 'burger',
        productName: 'Craft Burger',
        quantity: 1,
        basePrice: 12.5,
        selectedModifiers: [],
        unitPrice: 12.5,
        subtotal: 12.5,
        configurationSignature: 'burger::',
        course: 'main',
        status: 'pending',
      },
    ],
  };

  const createServiceInfo = (
    currentTable: RestaurantTable,
    currentOrder: TableOrder,
    patch: Partial<ServiceTableInfo> = {},
  ): ServiceTableInfo => {
    const courseGroups = ['drinks', 'starter', 'main', 'dessert', 'other']
      .map((course) => {
        const lines = currentOrder.lines.filter((line) => line.course === course);

        return {
          course,
          lines,
          quantity: lines.reduce((sum, line) => sum + line.quantity, 0),
          total: lines.reduce((sum, line) => sum + line.subtotal, 0),
        } as OrderCourseGroup;
      })
      .filter((group) => group.lines.length > 0);
    const pendingKitchenCount = currentOrder.lines.filter((line) => line.status === 'pending').reduce((sum, line) => sum + line.quantity, 0);

    return {
      table: currentTable,
      order: currentOrder,
      courseGroups,
      pendingKitchenCount,
      servicePhase: { course: 'main', status: 'pending' },
      nextAction: pendingKitchenCount > 0 ? { type: 'send_kitchen', count: pendingKitchenCount } : { type: 'none', count: 0 },
      canSendToKitchen: pendingKitchenCount > 0,
      canMarkServed: currentOrder.lines.some((line) => line.status !== 'served'),
      canCharge: currentOrder.total > 0,
      canMarkCleaning: true,
      canFreeTable: false,
      ...patch,
    };
  };

  it('renders selected table details, order lines, and service actions', async () => {
    const i18n = provideI18nTesting();
    const increaseProduct = vi.fn();
    const decreaseProduct = vi.fn();

    const { fixture, container } = await render(ServiceTablePanel, {
      imports: [...i18n.imports],
      providers: [...i18n.providers],
      inputs: {
        serviceInfo: createServiceInfo(table, order, {
          canSendToKitchen: true,
          canMarkServed: true,
          canCharge: true,
          canMarkCleaning: true,
        }),
        title: 'Mesa 1',
        errorMessage: null,
      },
    });
    fixture.componentInstance.increaseProduct.subscribe(increaseProduct);
    fixture.componentInstance.decreaseProduct.subscribe(decreaseProduct);

    expect(screen.getByLabelText('Panel de mesa seleccionada')).toBeTruthy();
    expect(screen.getByRole('heading', { name: 'Mesa 1' })).toBeTruthy();
    expect(screen.getByText('Ocupada · 25m · Principal pendiente · 12,50 €')).toBeTruthy();
    expect(screen.getByText('Fase')).toBeTruthy();
    expect(screen.getByText('Principal pendiente')).toBeTruthy();
    expect(screen.getByText('4 pax')).toBeTruthy();
    expect(screen.getByText('1 x Craft Burger')).toBeTruthy();
    expect(container.querySelector('.theme-order-line')).toBeTruthy();
    expect(container.querySelector('.theme-quantity-stepper')).toBeTruthy();
    fireEvent.click(screen.getByRole('button', { name: 'Añadir una unidad de Craft Burger' }));
    fireEvent.click(screen.getByRole('button', { name: 'Quitar una unidad de Craft Burger' }));
    expect(increaseProduct).toHaveBeenCalledWith('line-burger');
    expect(decreaseProduct).toHaveBeenCalledWith('line-burger');
    expect(screen.getByRole('button', { name: /Cocina/i })).toBeTruthy();
    expect(screen.getByRole('button', { name: /Cobrar/i })).toBeTruthy();
    expect(screen.queryByText('Añadir rápido')).toBeNull();
  });

  it('groups order lines by course and highlights the next service action', async () => {
    const i18n = provideI18nTesting();
    const multiCourseOrder: TableOrder = {
      ...order,
      total: 17,
      lines: [
        {
          id: 'line-water',
          productSnapshot: productSnapshot('water', 'Agua', 2, 'drinks', false),
          productId: 'water',
          productName: 'Agua',
          quantity: 1,
          basePrice: 2,
          selectedModifiers: [],
          unitPrice: 2,
          subtotal: 2,
          configurationSignature: 'water::',
          course: 'drinks',
          status: 'served',
        },
        ...order.lines,
      ],
    };

    await render(ServiceTablePanel, {
      imports: [...i18n.imports],
      providers: [...i18n.providers],
      inputs: {
        serviceInfo: createServiceInfo(table, multiCourseOrder, {
          canSendToKitchen: true,
          canMarkServed: false,
          canCharge: false,
          canMarkCleaning: false,
        }),
        title: 'Mesa 1',
        errorMessage: null,
      },
    });

    expect(screen.getByText('Siguiente: enviar 1 a cocina')).toBeTruthy();
    expect(screen.getByText('Pendiente cocina: 1')).toBeTruthy();
    expect(screen.getByRole('heading', { name: 'Bebidas' })).toBeTruthy();
    expect(screen.getByRole('heading', { name: 'Principal' })).toBeTruthy();
    expect(screen.getByText('1 x Agua')).toBeTruthy();
    expect(screen.getByText('1 x Craft Burger')).toBeTruthy();
  });

  it('renders combo slot selections with supplements', async () => {
    const i18n = provideI18nTesting();
    const comboOrder: TableOrder = {
      ...order,
      total: 16.5,
      lines: [
        {
          id: 'line-combo',
          productSnapshot: {
            ...productSnapshot('product-16', 'Classic Burger Menu', 13.5, 'main'),
            productType: 'combo',
          },
          productId: 'product-16',
          productName: 'Classic Burger Menu',
          quantity: 1,
          basePrice: 13.5,
          selectedModifiers: [],
          selectedComboSlots: [
            {
              slotId: 'combo-burger',
              slotName: 'Burger',
              selectedProducts: [
                {
                  productId: 'product-7',
                  productName: 'Truffle Burger',
                  productType: 'simple',
                  course: 'main',
                  preparationPolicy: { route: 'kitchen', requiresReadyBeforeServe: true },
                  supplementPrice: 2,
                },
              ],
            },
            {
              slotId: 'combo-side',
              slotName: 'Side',
              selectedProducts: [
                {
                  productId: 'product-9',
                  productName: 'Patatas Bravas',
                  productType: 'simple',
                  course: 'starter',
                  preparationPolicy: { route: 'kitchen', requiresReadyBeforeServe: true },
                  supplementPrice: 1,
                },
              ],
            },
            {
              slotId: 'combo-drink',
              slotName: 'Drink',
              selectedProducts: [
                {
                  productId: 'product-10',
                  productName: 'Water',
                  productType: 'simple',
                  course: 'drinks',
                  preparationPolicy: { route: 'bar', requiresReadyBeforeServe: false },
                  supplementPrice: 0,
                },
              ],
            },
          ],
          unitPrice: 16.5,
          subtotal: 16.5,
          configurationSignature: 'combo:product-16',
          course: 'main',
          status: 'pending',
        },
      ],
    };

    await render(ServiceTablePanel, {
      imports: [...i18n.imports],
      providers: [...i18n.providers],
      inputs: {
        serviceInfo: createServiceInfo(table, comboOrder),
        title: 'Mesa 1',
        errorMessage: null,
      },
    });

    expect(screen.getByText('1 x Classic Burger Menu')).toBeTruthy();
    expect(screen.getByText(/Burger:/)).toBeTruthy();
    expect(screen.getByText(/Truffle Burger \+2,00/)).toBeTruthy();
    expect(screen.getByText(/Side:/)).toBeTruthy();
    expect(screen.getByText(/Patatas Bravas \+1,00/)).toBeTruthy();
    expect(screen.getByText(/Drink:/)).toBeTruthy();
    expect(screen.getByText(/Water/)).toBeTruthy();
  });

  it('renders platter included components on order lines', async () => {
    const i18n = provideI18nTesting();
    const platterOrder: TableOrder = {
      ...order,
      total: 12.9,
      lines: [
        {
          id: 'line-platter',
          productSnapshot: {
            ...productSnapshot('product-17', 'Plato combinado de lomo', 12.9, 'main'),
            productType: 'platter',
          },
          productId: 'product-17',
          productName: 'Plato combinado de lomo',
          quantity: 1,
          basePrice: 12.9,
          selectedModifiers: [],
          platterComponents: [
            { id: 'platter-loin', name: 'Lomo', quantity: 1, removable: false, replaceable: false },
            { id: 'platter-egg', name: 'Huevo', quantity: 1, removable: true, replaceable: false },
            { id: 'platter-fries', name: 'Patatas', quantity: 1, removable: true, replaceable: false },
            { id: 'platter-salad', name: 'Ensalada', quantity: 1, removable: true, replaceable: false },
          ],
          unitPrice: 12.9,
          subtotal: 12.9,
          configurationSignature: 'product-17::',
          course: 'main',
          status: 'pending',
        },
      ],
    };

    await render(ServiceTablePanel, {
      imports: [...i18n.imports],
      providers: [...i18n.providers],
      inputs: {
        serviceInfo: createServiceInfo(table, platterOrder),
        title: 'Mesa 1',
        errorMessage: null,
      },
    });

    expect(screen.getByText('1 x Plato combinado de lomo')).toBeTruthy();
    expect(screen.getByText(/Incluye:/)).toBeTruthy();
    expect(screen.getByText(/lomo, huevo, patatas, ensalada/)).toBeTruthy();
  });

  it('keeps line preparation compact while preserving removal and notes', async () => {
    const i18n = provideI18nTesting();
    const removeProduct = vi.fn();
    const updateProductNote = vi.fn();
    const kitchenOrder: TableOrder = {
      ...order,
      lines: [
        {
          ...order.lines[0],
          status: 'sent_to_kitchen',
          kitchenNote: 'Sin cebolla',
          note: 'Sin cebolla',
        },
      ],
    };

    const { fixture } = await render(ServiceTablePanel, {
      imports: [...i18n.imports],
      providers: [...i18n.providers],
      inputs: {
        serviceInfo: createServiceInfo(table, kitchenOrder, {
          canSendToKitchen: false,
          canMarkServed: true,
        }),
        title: 'Mesa 1',
        errorMessage: null,
      },
    });
    fixture.componentInstance.removeProduct.subscribe(removeProduct);
    fixture.componentInstance.updateProductNote.subscribe(updateProductNote);

    expect(screen.getByText('En cocina')).toBeTruthy();
    expect(screen.queryByRole('button', { name: 'Marcar Craft Burger como preparado' })).toBeNull();
    expect(screen.queryByRole('button', { name: 'Marcar Craft Burger como servido' })).toBeNull();

    fireEvent.input(screen.getByRole('textbox', { name: 'Nota para Craft Burger' }), { target: { value: 'Muy hecho' } });
    fireEvent.click(screen.getByRole('button', { name: 'Eliminar Craft Burger del pedido' }));

    expect(updateProductNote).toHaveBeenCalledWith({ lineId: 'line-burger', note: 'Muy hecho' });
    expect(removeProduct).toHaveBeenCalledWith('line-burger');
  });

  it('shows picked up line status without preparation controls', async () => {
    const i18n = provideI18nTesting();
    const pickedUpOrder: TableOrder = {
      ...order,
      lines: [
        {
          ...order.lines[0],
          status: 'picked_up',
          pickedUpAt: '2026-06-10T12:20:00.000Z',
        },
      ],
    };

    await render(ServiceTablePanel, {
      imports: [...i18n.imports],
      providers: [...i18n.providers],
      inputs: {
        serviceInfo: createServiceInfo(table, pickedUpOrder, {
          canSendToKitchen: false,
          canMarkServed: true,
        }),
        title: 'Mesa 1',
        errorMessage: null,
      },
    });

    expect(screen.getByText('Recogido')).toBeTruthy();
    expect(screen.queryByRole('button', { name: 'Marcar Craft Burger como servido' })).toBeNull();
    expect(screen.queryByRole('button', { name: 'Marcar Craft Burger como preparado' })).toBeNull();
  });

  it('disables closing actions until the table can be closed and confirms before freeing it', async () => {
    const i18n = provideI18nTesting();
    const freeTable = vi.fn();
    const { fixture } = await render(ServiceTablePanel, {
      imports: [...i18n.imports],
      providers: [...i18n.providers],
      inputs: {
        serviceInfo: createServiceInfo(table, order, {
          canSendToKitchen: false,
          canMarkServed: false,
          canCharge: false,
          canMarkCleaning: true,
          canFreeTable: false,
        }),
        title: 'Mesa 1',
        errorMessage: null,
      },
    });
    fixture.componentInstance.freeTable.subscribe(freeTable);

    expect(screen.getByRole('button', { name: /Cobrar la mesa seleccionada/i }).hasAttribute('disabled')).toBe(true);
    expect(screen.getByRole('button', { name: /Liberar la mesa seleccionada/i }).hasAttribute('disabled')).toBe(true);

    fixture.componentRef.setInput(
      'serviceInfo',
      createServiceInfo(table, order, {
        canSendToKitchen: false,
        canMarkServed: false,
        canCharge: false,
        canMarkCleaning: true,
        canFreeTable: true,
      }),
    );
    fixture.detectChanges();
    fireEvent.click(screen.getByRole('button', { name: /Liberar la mesa seleccionada/i }));

    const dialog = screen.getByRole('dialog', { name: 'Liberar mesa' });
    expect(dialog).toBeTruthy();
    expect(freeTable).not.toHaveBeenCalled();

    fireEvent.click(within(dialog).getByRole('button', { name: 'Liberar mesa' }));

    expect(freeTable).toHaveBeenCalledTimes(1);
  });
});
