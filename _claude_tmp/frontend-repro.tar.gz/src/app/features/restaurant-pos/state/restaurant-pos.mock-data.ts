import { MOCK_MENU_PRODUCTS } from '../../menu/services/menu-mock.service';
import type { FloorElement, OrdersByTable, Product, RestaurantTable, TableOrder } from '../models/restaurant-pos.models';

export const DEFAULT_GRID_ROWS = 20;
export const DEFAULT_GRID_COLUMNS = 20;

export const MOCK_FLOOR_ELEMENTS: FloorElement[] = [
  {
    id: 'floor-element-1',
    type: 'table',
    label: 'M1',
    x: 1,
    y: 1,
    width: 2,
    height: 2,
    tableId: 'table-1',
  },
  {
    id: 'floor-element-2',
    type: 'table',
    label: 'M2',
    x: 5,
    y: 1,
    width: 2,
    height: 2,
    tableId: 'table-2',
  },
  {
    id: 'floor-element-3',
    type: 'bar',
    label: 'Bar',
    x: 1,
    y: 7,
    width: 3,
    height: 1,
  },
  {
    id: 'floor-element-4',
    type: 'kitchen',
    label: 'Kitchen',
    x: 6,
    y: 7,
    width: 3,
    height: 1,
  },
  {
    id: 'floor-element-5',
    type: 'entrance',
    label: 'Entrance',
    x: 8,
    y: 0,
    width: 2,
    height: 1,
  },
  {
    id: 'floor-element-6',
    type: 'stool',
    label: 'Stool 1',
    x: 1,
    y: 5,
    width: 1,
    height: 1,
    tableId: 'stool-1',
  },
  {
    id: 'floor-element-7',
    type: 'stool',
    label: 'Stool 2',
    x: 2,
    y: 5,
    width: 1,
    height: 1,
    tableId: 'stool-2',
  },
  {
    id: 'floor-element-8',
    type: 'stool',
    label: 'Stool 3',
    x: 3,
    y: 5,
    width: 1,
    height: 1,
    tableId: 'stool-3',
  },
];

export const MOCK_RESTAURANT_TABLES: RestaurantTable[] = [
  {
    id: 'table-1',
    number: 1,
    capacity: 2,
    status: 'free',
    total: 0,
    openDuration: '12m',
  },
  {
    id: 'table-2',
    number: 2,
    capacity: 4,
    status: 'free',
    total: 0,
    openDuration: '34m',
  },
  {
    id: 'table-3',
    number: 3,
    capacity: 6,
    status: 'reserved',
    total: 0,
    openDuration: '1h 05m',
  },
  {
    id: 'table-4',
    number: 4,
    capacity: 4,
    status: 'free',
    total: 0,
    openDuration: '1h 25m',
  },
  {
    id: 'stool-1',
    number: 5,
    capacity: 1,
    status: 'free',
    total: 0,
    openDuration: '0m',
  },
  {
    id: 'stool-2',
    number: 6,
    capacity: 1,
    status: 'free',
    total: 0,
    openDuration: '0m',
  },
  {
    id: 'stool-3',
    number: 7,
    capacity: 1,
    status: 'free',
    total: 0,
    openDuration: '0m',
  },
];

export const MOCK_PRODUCTS: Product[] = MOCK_MENU_PRODUCTS;

const createOpenOrder = (tableId: string): TableOrder => ({
  tableId,
  lines: [],
  total: 0,
  status: 'open',
  paymentMethod: 'pending',
});

export const MOCK_ORDERS_BY_TABLE: OrdersByTable = MOCK_RESTAURANT_TABLES.reduce<OrdersByTable>(
  (orders, table) => ({
    ...orders,
    [table.id]: createOpenOrder(table.id),
  }),
  {},
);
