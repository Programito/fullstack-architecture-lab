import { computed, inject, Injectable, signal } from '@angular/core';

import { KEY_VALUE_STORAGE } from '../../shared/utils/storage/key-value-storage';
import type { PermissionName } from './models/permission.model';
import type { AccountType, AuthResponseDto } from './api/identity-api.models';

const STORAGE_KEY = 'identity.session';

export type SessionScopes = {
  organizations: string[];
  restaurants: string[];
};

export type IdentitySessionSnapshot = {
  userId: string | null;
  roles: string[];
  permissions: PermissionName[];
  accessToken: string | null;
  scopes: SessionScopes;
  accountType: AccountType | null;
};

const EMPTY_SESSION: IdentitySessionSnapshot = {
  userId: null,
  roles: [],
  permissions: [],
  accessToken: null,
  scopes: { organizations: [], restaurants: [] },
  accountType: null,
};

@Injectable({
  providedIn: 'root',
})
export class IdentitySessionStore {
  private readonly storage = inject(KEY_VALUE_STORAGE);
  private readonly sessionState = signal<IdentitySessionSnapshot>(this.readFromStorage());

  readonly session = this.sessionState.asReadonly();
  readonly roles = computed(() => this.sessionState().roles);
  readonly permissions = computed(() => this.sessionState().permissions);
  readonly scopes = computed(() => this.sessionState().scopes);
  readonly isAuthenticated = computed(() => Boolean(this.sessionState().userId));
  readonly accountType = computed(() => this.sessionState().accountType);
  readonly isDemoAccount = computed(() => this.accountType() === 'demo');

  hasPermission(permission: PermissionName): boolean {
    return this.permissions().includes(permission);
  }

  hasRole(role: string): boolean {
    return this.roles().includes(role);
  }

  setAuthResponse(response: AuthResponseDto): void {
    this.setSession({
      userId: response.user.id,
      roles: response.roles,
      permissions: response.permissions,
      accessToken: response.accessToken,
      scopes: response.scopes ?? { organizations: [], restaurants: [] },
      accountType: response.user.accountType,
    });
  }

  setSession(session: IdentitySessionSnapshot): void {
    const normalized: IdentitySessionSnapshot = {
      userId: session.userId,
      roles: [...new Set(session.roles)],
      permissions: [...new Set(session.permissions)],
      accessToken: session.accessToken,
      scopes: {
        organizations: Array.isArray(session.scopes?.organizations) ? [...new Set(session.scopes.organizations)] : [],
        restaurants: Array.isArray(session.scopes?.restaurants) ? [...new Set(session.scopes.restaurants)] : [],
      },
      accountType: isAccountType(session.accountType) ? session.accountType : null,
    };
    this.sessionState.set(normalized);
    this.storage.setItem(STORAGE_KEY, JSON.stringify(normalized));
  }

  clear(): void {
    this.sessionState.set(EMPTY_SESSION);
    this.storage.removeItem(STORAGE_KEY);
  }

  private readFromStorage(): IdentitySessionSnapshot {
    const rawValue = this.storage.getItem(STORAGE_KEY);
    if (!rawValue) {
      return EMPTY_SESSION;
    }

    try {
      const parsed = JSON.parse(rawValue) as Partial<IdentitySessionSnapshot>;
      const rawScopes = parsed.scopes as { organizations?: unknown; restaurants?: unknown } | undefined;
      return {
        userId: typeof parsed.userId === 'string' ? parsed.userId : null,
        roles: Array.isArray(parsed.roles) ? [...new Set(parsed.roles.filter(isString))] : [],
        permissions: Array.isArray(parsed.permissions)
          ? [...new Set(parsed.permissions.filter(isPermissionName))]
          : [],
        accessToken: typeof parsed.accessToken === 'string' ? parsed.accessToken : null,
        scopes: {
          organizations: Array.isArray(rawScopes?.organizations) ? rawScopes.organizations.filter(isString) : [],
          restaurants: Array.isArray(rawScopes?.restaurants) ? rawScopes.restaurants.filter(isString) : [],
        },
        accountType: isAccountType(parsed.accountType) ? parsed.accountType : null,
      };
    } catch {
      this.storage.removeItem(STORAGE_KEY);
      return EMPTY_SESSION;
    }
  }
}

function isString(value: unknown): value is string {
  return typeof value === 'string';
}

function isPermissionName(value: unknown): value is PermissionName {
  return (
    value === 'service' ||
    value === 'time_tracking' ||
    value === 'menu' ||
    value === 'kitchen' ||
    value === 'layout' ||
    value === 'reservations' ||
    value === 'dashboard'
  );
}

function isAccountType(value: unknown): value is AccountType {
  return value === 'regular' || value === 'demo' || value === 'system' || value === 'test';
}
